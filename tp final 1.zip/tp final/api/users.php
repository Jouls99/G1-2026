<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

handleOptions();

$file = dataPath('users.json');
$method = requestMethod();

if ($method === 'GET') {
    $users = readJsonFile($file);
    // Para seguridad, ocultamos contraseñas al listar
    $safeUsers = array_map(function ($u) {
        return [
            'usuario' => $u['usuario'] ?? '',
            'role' => $u['role'] ?? 'vendedor',
            'createdAt' => $u['createdAt'] ?? null
        ];
    }, $users);
    sendJson($safeUsers);
}

if ($method === 'POST') {
    $body = getJsonBody();
    $usuario = trim((string) ($body['usuario'] ?? ''));
    $password = (string) ($body['password'] ?? '');
    $role = trim((string) ($body['role'] ?? 'vendedor'));
    if ($role === '') {
        $role = 'vendedor';
    }

    if ($usuario === '' || $password === '') {
        sendJson(['error' => 'missing_fields', 'message' => 'Completá todos los campos.'], 400);
    }

    $users = readJsonFile($file);

    foreach ($users as $user) {
        if (strcasecmp((string) ($user['usuario'] ?? ''), $usuario) === 0) {
            sendJson(['error' => 'user_exists', 'message' => 'El usuario ya existe.'], 409);
        }
    }

    $users[] = [
        'usuario' => $usuario,
        'password' => $password,
        'role' => $role,
        'createdAt' => date('c')
    ];

    if (!writeJsonFile($file, $users)) {
        sendJson(['error' => 'save_error', 'message' => 'Error al guardar usuario.'], 500);
    }

    // Iniciar sesión en PHP
    $_SESSION['user'] = [
        'usuario' => $usuario,
        'role' => $role,
        'loginAt' => date('c')
    ];

    sendJson(['ok' => true, 'message' => 'Usuario registrado con éxito.']);
}

sendJson(['error' => 'method_not_allowed'], 405);
