<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Envía una respuesta en formato JSON con los encabezados adecuados.
 */
function sendJson(mixed $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/**
 * Responde inmediatamente a solicitudes OPTIONS (CORS preflight).
 */
function handleOptions(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
        sendJson(['ok' => true]);
    }
}

/**
 * Obtiene el cuerpo de la petición parseado como JSON o desde $_POST.
 */
function getJsonBody(): ?array
{
    $raw = file_get_contents('php://input');
    if ($raw !== false && trim($raw) !== '') {
        $data = json_decode($raw, true);
        if (is_array($data)) {
            return $data;
        }
    }

    if (!empty($_POST)) {
        return $_POST;
    }

    return null;
}

/**
 * Lee un archivo JSON de forma segura con bloqueo compartido.
 */
function readJsonFile(string $path): array
{
    if (!file_exists($path)) {
        return [];
    }

    $fp = fopen($path, 'r');
    if (!$fp) {
        return [];
    }

    // Bloqueo compartido para lectura
    flock($fp, LOCK_SH);
    $size = filesize($path);
    $content = $size > 0 ? fread($fp, $size) : '';
    flock($fp, LOCK_UN);
    fclose($fp);

    if ($content === false || trim($content) === '') {
        return [];
    }

    $data = json_decode($content, true);
    return is_array($data) ? $data : [];
}

/**
 * Guarda un array en un archivo JSON de forma atómica y segura con bloqueo exclusivo.
 */
function writeJsonFile(string $path, array $data): bool
{
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($json === false) {
        return false;
    }

    // Escritura segura mediante archivo temporal y renombrado atómico o con LOCK_EX
    $dir = dirname($path);
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }

    $fp = fopen($path, 'c+');
    if (!$fp) {
        return false;
    }

    if (flock($fp, LOCK_EX)) {
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, $json . PHP_EOL);
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);
        return true;
    }

    fclose($fp);
    return false;
}

/**
 * Retorna la ruta absoluta a un archivo de datos.
 */
function dataPath(string $filename): string
{
    return dirname(__DIR__) . DIRECTORY_SEPARATOR . $filename;
}

/**
 * Obtiene el método HTTP en mayúsculas.
 */
function requestMethod(): string
{
    return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
}

/**
 * Verifica si hay una sesión activa de usuario en la API.
 */
function getApiUser(): ?array
{
    return $_SESSION['user'] ?? null;
}
