<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Comprueba si hay una sesión de usuario activa.
 */
function isLoggedIn(): bool
{
    return !empty($_SESSION['user']) && is_array($_SESSION['user']);
}

/**
 * Obtiene el usuario autenticado actual o null.
 */
function getCurrentUser(): ?array
{
    return $_SESSION['user'] ?? null;
}

/**
 * Protege una página requiriendo que el usuario esté autenticado.
 * Si no lo está, redirige a la pantalla de login.
 */
function requireAuth(string $redirectUrl = 'registroinicio.php'): void
{
    if (!isLoggedIn()) {
        header('Location: ' . $redirectUrl);
        exit;
    }
}

/**
 * Si el usuario ya está autenticado, lo redirige al panel principal.
 */
function redirectIfLoggedIn(string $targetUrl = 'prueba2.php'): void
{
    if (isLoggedIn()) {
        header('Location: ' . $targetUrl);
        exit;
    }
}

/**
 * Cierra la sesión activa y limpia los datos.
 */
function logoutUser(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }
    session_destroy();
}
