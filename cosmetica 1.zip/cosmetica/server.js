const express = require("express");
const cors = require("cors");

const db = require("./config/database");

const app = express();

const PORT = 3000;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
    res.send("¡Backend de la cosmética funcionando!");
});

app.get("/api/prueba-db", async (req, res) => {
    try {
        const [resultado] = await db.query("SELECT 1 AS conectado");

        res.json({
            mensaje: "Conexión con MySQL exitosa",
            resultado: resultado
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            mensaje: "Error al conectar con MySQL"
        });
    }
});

app.get("/api/productos", async (req, res) => {
    try {
        const sql = `
            SELECT
                productos.id,
                productos.codigo,
                productos.nombre,
                categorias.nombre AS categoria,
                marcas.nombre AS marca,
                productos.precio,
                productos.stock,
                productos.stock_minimo
            FROM productos
            INNER JOIN categorias
                ON productos.categoria_id = categorias.id
            INNER JOIN marcas
                ON productos.marca_id = marcas.id
        `;

        const [productos] = await db.query(sql);

        res.json(productos);

    } catch (error) {
        console.error(error);

        res.status(500).json({
            mensaje: "Error al obtener los productos"
        });
    }
});


app.post("/api/productos", async (req, res) => {
    try {
        const {
            codigo,
            nombre,
            categoria_id,
            marca_id,
            precio,
            stock,
            stock_minimo
        } = req.body;

        const sql = `
            INSERT INTO productos
            (codigo, nombre, categoria_id, marca_id, precio, stock, stock_minimo)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;

        const [resultado] = await db.query(sql, [
            codigo,
            nombre,
            categoria_id,
            marca_id,
            precio,
            stock,
            stock_minimo
        ]);

        res.status(201).json({
            mensaje: "Producto creado correctamente",
            id: resultado.insertId
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            mensaje: "Error al crear el producto"
        });
    }
});

app.put("/api/productos/:id", async (req, res) => {
    try {
        const { id } = req.params;

        const {
            codigo,
            nombre,
            categoria_id,
            marca_id,
            precio,
            stock,
            stock_minimo
        } = req.body;

        const sql = `
            UPDATE productos
            SET
                codigo = ?,
                nombre = ?,
                categoria_id = ?,
                marca_id = ?,
                precio = ?,
                stock = ?,
                stock_minimo = ?
            WHERE id = ?
        `;

        const [resultado] = await db.query(sql, [
            codigo,
            nombre,
            categoria_id,
            marca_id,
            precio,
            stock,
            stock_minimo,
            id
        ]);

        if (resultado.affectedRows === 0) {
            return res.status(404).json({
                mensaje: "Producto no encontrado"
            });
        }

        res.json({
            mensaje: "Producto actualizado correctamente"
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            mensaje: "Error al actualizar el producto"
        });
    }
});

app.delete("/api/productos/:id", async (req, res) => {
    try {
        const { id } = req.params;

        const sql = "DELETE FROM productos WHERE id = ?";

        const [resultado] = await db.query(sql, [id]);

        if (resultado.affectedRows === 0) {
            return res.status(404).json({
                mensaje: "Producto no encontrado"
            });
        }

        res.json({
            mensaje: "Producto eliminado correctamente"
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            mensaje: "Error al eliminar el producto"
        });
    }
});

app.listen(PORT, () => {
    console.log(`Servidor funcionando en http://localhost:${PORT}`);
});

