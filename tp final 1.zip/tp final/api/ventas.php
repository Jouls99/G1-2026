<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

handleOptions();

$ventasFile = dataPath('ventas.json');
$inventarioFile = dataPath('inventario.json');
$method = requestMethod();

// GET: Listar ventas
if ($method === 'GET') {
    $ventas = readJsonFile($ventasFile);
    sendJson($ventas);
}

// POST: Registrar una nueva venta
if ($method === 'POST') {
    $payload = getJsonBody();

    if (
        !is_array($payload)
        || !isset($payload['productos'])
        || !is_array($payload['productos'])
        || count($payload['productos']) === 0
    ) {
        sendJson(['error' => 'invalid_payload', 'message' => 'La venta debe contener al menos un producto.'], 400);
    }

    $ventas = readJsonFile($ventasFile);
    $inventario = readJsonFile($inventarioFile);

    // Calcular total y validar stock si se solicita deducción automática en backend
    $totalCalculado = 0;
    $productosVenta = [];

    foreach ($payload['productos'] as $prod) {
        if (!is_array($prod) || empty($prod['codigo'])) {
            continue;
        }
        $codigo = trim((string) $prod['codigo']);
        $cantidad = (int) ($prod['cantidad'] ?? 1);
        $precio = (float) ($prod['precio'] ?? 0);
        $nombre = trim((string) ($prod['nombre'] ?? 'Producto'));
        $categoria = trim((string) ($prod['categoria'] ?? 'General'));

        $totalCalculado += $precio * $cantidad;

        $productosVenta[] = [
            'id' => $prod['id'] ?? (int) (microtime(true) * 1000),
            'nombre' => $nombre,
            'codigo' => $codigo,
            'cantidad' => $cantidad,
            'precio' => $precio,
            'categoria' => $categoria
        ];
    }

    $totalVenta = (float) ($payload['total'] ?? $totalCalculado);
    $totalInv = isset($payload['totalInventario']) ? (float) $payload['totalInventario'] : null;

    $venta = [
        'id' => (string) ($payload['id'] ?? (int) (microtime(true) * 1000)),
        'productos' => $productosVenta,
        'total' => $totalVenta,
        'dinero' => (float) ($payload['dinero'] ?? $totalVenta),
        'fecha' => $payload['fecha'] ?? date('c'),
    ];

    if ($totalInv !== null) {
        $venta['totalInventario'] = $totalInv;
    }

    $ventas[] = $venta;

    if (!writeJsonFile($ventasFile, $ventas)) {
        sendJson(['error' => 'save_error', 'message' => 'No se pudo registrar la venta.'], 500);
    }

    sendJson(['ok' => true, 'venta' => $venta]);
}

// PUT: Actualizar lista completa de ventas o una venta en particular
if ($method === 'PUT') {
    $payload = getJsonBody();

    if (!is_array($payload)) {
        sendJson(['error' => 'invalid_payload'], 400);
    }

    // Si es un array de ventas completo
    if (isset($payload[0]) || empty($payload)) {
        if (!writeJsonFile($ventasFile, $payload)) {
            sendJson(['error' => 'save_error'], 500);
        }
        sendJson(['ok' => true, 'count' => count($payload)]);
    }

    // Si es una sola venta a modificar
    $saleId = (string) ($payload['id'] ?? '');
    if ($saleId !== '') {
        $ventas = readJsonFile($ventasFile);
        $updated = false;
        foreach ($ventas as &$v) {
            if ((string) ($v['id'] ?? '') === $saleId) {
                $v = array_merge($v, $payload);
                $updated = true;
                break;
            }
        }
        if ($updated && writeJsonFile($ventasFile, $ventas)) {
            sendJson(['ok' => true, 'message' => 'Venta actualizada.']);
        }
    }

    sendJson(['error' => 'save_error'], 500);
}

// DELETE: Eliminar una venta por ID
if ($method === 'DELETE') {
    $id = $_GET['id'] ?? null;
    if (!$id) {
        $body = getJsonBody();
        $id = $body['id'] ?? null;
    }

    if (!$id) {
        sendJson(['error' => 'missing_id', 'message' => 'Se requiere el parámetro ID de la venta.'], 400);
    }

    $idStr = (string) $id;
    $ventas = readJsonFile($ventasFile);
    $initialCount = count($ventas);
    $ventas = array_values(array_filter($ventas, function ($v) use ($idStr) {
        return (string) ($v['id'] ?? '') !== $idStr;
    }));

    if (count($ventas) === $initialCount) {
        sendJson(['error' => 'not_found', 'message' => 'Venta no encontrada.'], 404);
    }

    if (!writeJsonFile($ventasFile, $ventas)) {
        sendJson(['error' => 'save_error', 'message' => 'Error al eliminar venta.'], 500);
    }

    sendJson(['ok' => true, 'message' => 'Venta eliminada correctamente.']);
}

sendJson(['error' => 'method_not_allowed'], 405);
