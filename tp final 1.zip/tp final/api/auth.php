<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

handleOptions();

$action = $_GET['action'] ?? ($_POST['action'] ?? 'check');
$file = dataPath('users.json');
$method = requestMethod();

// 1. Comprobar estado de autenticación
if ($action === 'check') {
    $user = getApiUser();
    sendJson([
        'ok' => true,
        'loggedIn' => $user !== null,
        'user' => $user
    ]);
}

// 2. Iniciar sesión (Login)
if ($action === 'login' && $method === 'POST') {
    $body = getJsonBody();
    $usuario = trim((string) ($body['usuario'] ?? ''));
    $password = (string) ($body['password'] ?? '');

    if ($usuario === '' || $password === '') {
        sendJson(['ok' => false, 'error' => 'missing_fields', 'message' => 'Completá usuario y contraseña.'], 400);
    }

    $users = readJsonFile($file);
    $found = null;

    foreach ($users as $u) {
        if (strcasecmp((string) ($u['usuario'] ?? ''), $usuario) === 0) {
            $found = $u;
            break;
        }
    }

    if (!$found || (string) ($found['password'] ?? '') !== $password) {
        sendJson(['ok' => false, 'error' => 'invalid_credentials', 'message' => 'Usuario o contraseña incorrectos.'], 401);
    }

    // Iniciar sesión en PHP
    $_SESSION['user'] = [
        'usuario' => $found['usuario'],
        'role' => $found['role'] ?? 'vendedor',
        'loginAt' => date('c')
    ];

    sendJson([
        'ok' => true,
        'message' => 'Inicio de sesión exitoso.',
        'user' => $_SESSION['user']
    ]);
}

// 3. Registrar nuevo usuario
if ($action === 'register' && $method === 'POST') {
    $body = getJsonBody();
    $usuario = trim((string) ($body['usuario'] ?? ''));
    $password = (string) ($body['password'] ?? '');
    $role = trim((string) ($body['role'] ?? 'vendedor'));
    if ($role === '') {
        $role = 'vendedor';
    }

    if ($usuario === '' || $password === '') {
        sendJson(['ok' => false, 'error' => 'missing_fields', 'message' => 'Completá todos los campos.'], 400);
    }

    $users = readJsonFile($file);

    foreach ($users as $u) {
        if (strcasecmp((string) ($u['usuario'] ?? ''), $usuario) === 0) {
            sendJson(['ok' => false, 'error' => 'user_exists', 'message' => 'Ese usuario ya existe.'], 409);
        }
    }

    $newUser = [
        'usuario' => $usuario,
        'password' => $password,
        'role' => $role,
        'createdAt' => date('c')
    ];

    $users[] = $newUser;

    if (!writeJsonFile($file, $users)) {
        sendJson(['ok' => false, 'error' => 'save_error', 'message' => 'No se pudo guardar el usuario.'], 500);
    }

    // Iniciar sesión automáticamente tras registro
    $_SESSION['user'] = [
        'usuario' => $usuario,
        'role' => $role,
        'loginAt' => date('c')
    ];

    sendJson([
        'ok' => true,
        'message' => 'Usuario registrado exitosamente.',
        'user' => $_SESSION['user']
    ]);
}

// 4. Cerrar sesión
if ($action === 'logout') {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }
    session_destroy();

    sendJson([
        'ok' => true,
        'message' => 'Sesión cerrada correctamente.'
    ]);
}

sendJson(['ok' => false, 'error' => 'invalid_action'], 400);
