<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

handleOptions();

$file = dataPath('inventario.json');
$method = requestMethod();

// GET: Obtener inventario
if ($method === 'GET') {
    $inventario = readJsonFile($file);
    sendJson($inventario);
}

// POST: Agregar un nuevo producto al inventario
if ($method === 'POST') {
    $body = getJsonBody();
    if (!is_array($body) || empty($body['nombre']) || empty($body['codigo'])) {
        sendJson(['error' => 'invalid_payload', 'message' => 'Faltan campos obligatorios (nombre, codigo).'], 400);
    }

    $inventario = readJsonFile($file);
    $codigo = trim((string) $body['codigo']);

    // Comprobar si el código ya existe
    foreach ($inventario as $p) {
        if (strcasecmp((string) ($p['codigo'] ?? ''), $codigo) === 0) {
            sendJson(['error' => 'item_exists', 'message' => 'Ya existe un producto con este código.'], 409);
        }
    }

    $precio = (float) ($body['precio'] ?? 0);
    $cantidad = (int) ($body['cantidad'] ?? ($body['stock'] ?? 0));
    $nuevoItem = [
        'categoria' => trim((string) ($body['categoria'] ?? 'General')),
        'nombre' => trim((string) $body['nombre']),
        'codigo' => $codigo,
        'precio' => $precio,
        'cantidad' => $cantidad,
        'total' => $precio * $cantidad
    ];

    if (!empty($body['subcategoria'])) {
        $nuevoItem['subcategoria'] = trim((string) $body['subcategoria']);
    }

    $inventario[] = $nuevoItem;

    if (!writeJsonFile($file, $inventario)) {
        sendJson(['error' => 'save_error', 'message' => 'No se pudo guardar el producto.'], 500);
    }

    sendJson(['ok' => true, 'item' => $nuevoItem]);
}

// PUT: Actualizar lista completa de inventario
if ($method === 'PUT') {
    $payload = getJsonBody();

    if (!is_array($payload)) {
        sendJson(['error' => 'invalid_payload', 'message' => 'El cuerpo debe ser un array de productos.'], 400);
    }

    // Normalizar datos del inventario
    $normalized = [];
    foreach ($payload as $item) {
        if (!is_array($item) || empty($item['codigo'])) {
            continue;
        }
        $precio = (float) ($item['precio'] ?? 0);
        $cantidad = (int) ($item['cantidad'] ?? ($item['stock'] ?? 0));
        $normalized[] = [
            'categoria' => trim((string) ($item['categoria'] ?? 'General')),
            'nombre' => trim((string) ($item['nombre'] ?? '')),
            'codigo' => trim((string) $item['codigo']),
            'precio' => $precio,
            'cantidad' => $cantidad,
            'total' => $precio * $cantidad,
            'subcategoria' => !empty($item['subcategoria']) ? trim((string) $item['subcategoria']) : null
        ];
    }

    if (!writeJsonFile($file, $normalized)) {
        sendJson(['error' => 'save_error', 'message' => 'Error al guardar el inventario.'], 500);
    }

    sendJson(['ok' => true, 'count' => count($normalized)]);
}

// DELETE: Eliminar un producto por código
if ($method === 'DELETE') {
    $codigo = $_GET['codigo'] ?? null;
    if (!$codigo) {
        $body = getJsonBody();
        $codigo = $body['codigo'] ?? null;
    }

    if (!$codigo) {
        sendJson(['error' => 'missing_code', 'message' => 'Se requiere el parámetro codigo.'], 400);
    }

    $inventario = readJsonFile($file);
    $initialCount = count($inventario);
    $inventario = array_values(array_filter($inventario, function ($p) use ($codigo) {
        return strcasecmp((string) ($p['codigo'] ?? ''), (string) $codigo) !== 0;
    }));

    if (count($inventario) === $initialCount) {
        sendJson(['error' => 'not_found', 'message' => 'Producto no encontrado.'], 404);
    }

    if (!writeJsonFile($file, $inventario)) {
        sendJson(['error' => 'save_error', 'message' => 'Error al guardar cambios.'], 500);
    }

    sendJson(['ok' => true, 'message' => 'Producto eliminado correctamente.']);
}

sendJson(['error' => 'method_not_allowed'], 405);
